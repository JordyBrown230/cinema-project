
class Constants{
  static const apiKey="92b77cc0a466dac6a03491fbe25d3220";
  static const imagePath="https://image.tmdb.org/t/p/w500";
  static const baseUrl="https://api.themoviedb.org";
}


